# YouTubeJS Migration Progress

- More Search Result....
- Comment support
- ~~Like & Dislike Count~~ Done.
- Playlist & Channel support
- Quality chooser
- HLS support

- Other....
